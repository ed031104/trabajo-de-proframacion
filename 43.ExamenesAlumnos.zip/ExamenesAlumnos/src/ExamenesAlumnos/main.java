package ExamenesAlumnos;
import java.util.Scanner;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		// Declarar una matriz de n filas y 4 columnas para almacenar los datos de los estudiantes.
        
		
		System.out.println("ingrese la cantidad de estudiantes:");
		int e=sc.nextInt();
		double[][] estudiantes = new double[e][4];
       

        // Leer los datos de los estudiantes.
        for (int i = 0; i < e; i++) {
            System.out.println("Ingrese los datos del estudiante " + (i+1) + ":");
            
            System.out.print("Nombre: ");
            String n = sc.next();
            estudiantes[i][0] = 0; // No se usa
            System.out.print("Nota1: ");
            estudiantes[i][1] = sc.nextDouble();
            System.out.print("Nota2: ");
            estudiantes[i][2] = sc.nextDouble();
            System.out.print("Nota3: ");
            estudiantes[i][3] = sc.nextDouble();
            sc.nextLine(); // Consumir la línea vacía después de las notas
        }

        // Calcular el promedio de las notas para cada estudiante.
        for (int i = 0; i < e; i++) {
            double promedio = (estudiantes[i][1] + estudiantes[i][2] + estudiantes[i][3]) / 3;
            System.out.println("El promedio de las notas para el estudiante "+ (i+1) + " es " + promedio);
        }
		
		
		

	}

}
