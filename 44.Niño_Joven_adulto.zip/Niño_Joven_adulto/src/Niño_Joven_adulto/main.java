package Niño_Joven_adulto;
import java.util.Scanner;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		
		System.out.println("si tu edad es menor de 13 eres un niño");
		System.out.println("si tu edad es de 13-25 eres un joven");
		System.out.println("si tu edad es mator de 25 eres un adulto");
		System.out.println("-----------------------------------------");
		System.out.println("ingresa tu edad");
		int edad = tc.nextInt();
		
		if (edad <= 0 ) {
			System.out.println("no se puede ingresar una edad menor o igual a cero");
		}
		if(edad >=1 && edad <=12) {
			System.out.println("eres un nino");
		}
		if(edad >= 13 && edad <= 25) {
			System.out.println("eres un joven");
		}
		if(edad > 25) {
			System.out.println("eres un adulto");
		}
		else {}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
