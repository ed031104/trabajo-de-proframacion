module Nvoltajes_Minimo_maximo {
}