package Nvoltajes_Minimo_maximo;
import java.util.Scanner;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input =new Scanner(System.in);
		
		 System.out.print("Ingrese la cantidad de voltajes: ");
	        int n = input.nextInt();

	        // Crear un arreglo de voltajes y pedir al usuario que ingrese cada valor
	        double[] voltajes = new double[n];
	        for (int i = 0; i < n; i++) {
	            System.out.print("Ingrese el voltaje " + (i+1) + ": ");
	            voltajes[i] = input.nextDouble();
	        }

	        // Calcular el voltaje mínimo, máximo y promedio
	        double minimo = voltajes[0];
	        double maximo = voltajes[0];
	        double suma = voltajes[0];
	        
	        for (int i = 1; i < n; i++) {
	            if (voltajes[i] < minimo) {
	                minimo = voltajes[i];
	            }
	            if (voltajes[i] > maximo) {
	                maximo = voltajes[i];
	            }
	            suma += voltajes[i];
	        }
	        double promedio = suma / n;

	        // Imprimir los resultados
	        System.out.println("Voltaje mínimo: " + minimo);
	        System.out.println("Voltaje máximo: " + maximo);
	        System.out.println("Voltaje promedio: " + promedio);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
