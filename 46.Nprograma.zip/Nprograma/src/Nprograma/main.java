package Nprograma;
import java.util.Arrays;
import java.util.Scanner;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		System.out.println("opciones");
		System.out.println("1.La suma de N elementos.");
		System.out.println("2.La suma de N elementos elevados al cuadrado.");
		System.out.println("3.El menor N elemento y la posicion del mismo dentro del arreglo.");
		System.out.println("4.El mayor N elemento y la posicion del mismo dentro del arreglo");
		System.out.println("5.El promedio de los N elementos.");
		System.out.println("6.Ordenar N elementos de forma ascendente.");
		System.out.println("7.Calcular el N modulo del arreglo.");
		System.out.println("-----------------------------------------------------------------");
		System.out.println("elige una opcion");
		int opcion = tc.nextInt();
		
		switch (opcion) {
		case 1:
			System.out.println("ingrese el valor de n:");
			int n=tc.nextInt();
			
			int suma = 0;

			for (int i = 0; i <= n; i++) {
			    suma += i;
			}

			System.out.println("La suma de los elementos del arreglo es: " + suma);
			break;
			
		case 2:
			System.out.println("ingrese el valor de n:");
			int nu=tc.nextInt();
			double [] arreg =new double [nu];
			int sum = 0;

			for (int i = 0; i <= nu; i++) {
			    sum += i * i;
			}

			System.out.println("La suma de los elementos al cuadrado del arreglo es: " + sum);
			
			break;
		case 3:
			// Pedimos al usuario que ingrese el tamaño del arreglo
	        System.out.print("Ingresa el tamaño del arreglo: ");
	        int En = tc.nextInt();
	        
	        // Creamos el arreglo y pedimos al usuario que ingrese sus elementos
	        int[] arreglo = new int[En];
	        for (int i = 0; i < En; i++) {
	            System.out.print("Ingresa el elemento " + (i + 1) + " del arreglo: ");
	            arreglo[i] = tc.nextInt();
	        }
	        
	        // Pedimos al usuario que ingrese el valor de n para el n-ésimo menor elemento
	        System.out.print("Ingresa el valor de n para el n-ésimo menor elemento: ");
	        int posicion = tc.nextInt();
	        
	        // Ordenamos el arreglo de menor a mayor
	        Arrays.sort(arreglo);
	        
	        // Imprimimos el n-ésimo menor elemento y su posición
	        System.out.println("El " + posicion + "-esimo menor elemento es: " + arreglo[posicion - 1]);
	        System.out.println("La posición del " + posicion + "-ésimo menor elemento en el arreglo es: " + (posicion - 1));
			    
			

			
			
			
			break;
		case 4:
			 // Pedimos al usuario que ingrese el arreglo
	        System.out.print("Ingrese el tamaño del arreglo: ");
	        int en = tc.nextInt();
	        int[] arregl = new int[en];
	        System.out.println("Ingrese los elementos del arreglo:");
	        for (int i = 0; i < en; i++) {
	            arregl[i] = tc.nextInt();
	        }

	        // Pedimos al usuario que ingrese el valor de n
	        System.out.print("Ingrese el valor de n: ");
	        int pos = tc.nextInt();

	        // Ordenamos el arreglo en orden descendente
	        Arrays.sort(arregl);
	        int n_esimo_elemento = arregl[en - pos];

	        // Encontramos la posición del n-ésimo elemento
	        int posicio = 0;
	        for (int i = 0; i < en; i++) {
	            if (arregl[i] == n_esimo_elemento) {
	                posicio = i;
	                break;
	            }
	        }

	        // Imprimimos los resultados
	        System.out.println("El " + pos + " elemento más grande es: " + n_esimo_elemento);
	        System.out.println("Su posición en el arreglo es: " + posicio);
			

			

			
			break;
		case 5:
			System.out.println("ingrese el valor de n:");
			int nume=tc.nextInt();
			double S = 0;

			for (int i = 0; i <= nume; i++) {
			    S += i;
			}

			double prome = S / nume;

			System.out.println("El promedio de los elementos del arreglo es: " + prome);
			
			break;
		case 6:
			int cont=0;
			System.out.println("ingrese el valor de n:");
			int N=tc.nextInt();
			for(int i=1; i<=N; i++) {  
				
				System.out.println("i;"+i);
				i=i+6;
			
			}
			System.out.println("este es el contador" +cont);
			System.out.println();
			for(int NU=N; NU>0; NU--) {
				System.out.println("n:"+NU);
			}

			
			break;
		case 7:
			
			System.out.println("ingresa el valor de n");
			int ene=tc.nextInt();
			int[] array = {ene};
			int modulo = 0;

			for (int i = 0; i <= ene; i++) {
			    modulo += Math.abs(i);
			}

			System.out.println("El modulo del arreglo es: " + modulo);
			break;
			
		default:
			break;
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
